This project just contains some example programs demonstrating how to
use usb4java.
